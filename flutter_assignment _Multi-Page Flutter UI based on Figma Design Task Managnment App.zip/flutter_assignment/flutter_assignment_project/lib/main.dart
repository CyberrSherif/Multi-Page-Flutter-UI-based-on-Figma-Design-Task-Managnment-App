import 'package:flutter/material.dart';
import 'routes/app_routes.dart';
import 'themes/app_theme.dart';

void main() {
  runApp(const TaskApp());
}

class TaskApp extends StatelessWidget {
  const TaskApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Task Manager',
      debugShowCheckedModeBanner: false,
      
      // Use the complete theme
      theme: AppTheme.lightTheme,
      
      // Routes - Start with welcome screen
      initialRoute: AppRoutes.welcome,
      routes: AppRoutes.routes,
    );
  }
}