import 'package:flutter/widgets.dart';
import '../views/welcome_view.dart';
import '../views/home_view.dart';
import '../views/tasks_view.dart';
import '../views/task_details_view.dart';
import '../views/add_task_view.dart';

class AppRoutes {
  static const String welcome = '/';
  static const String home = '/home';
  static const String tasks = '/tasks';
  static const String taskDetails = '/task-details';
  static const String addTask = '/add-task';

  static final routes = <String, WidgetBuilder>{
    welcome: (context) => const WelcomeView(),
    home: (context) => const HomeView(),
    tasks: (context) => const TasksView(),
    taskDetails: (context) => const TaskDetailsView(),
    addTask: (context) => const AddTaskView(),
  };
}