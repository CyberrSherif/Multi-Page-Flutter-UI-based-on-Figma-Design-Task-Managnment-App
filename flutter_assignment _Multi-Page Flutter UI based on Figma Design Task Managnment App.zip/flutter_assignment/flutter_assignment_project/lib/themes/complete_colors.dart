import 'package:flutter/material.dart';

/// Professional color scheme for Task Management App
/// Based on modern task management design patterns
class AppColors {
  // Primary Colors
  static const Color primary = Color(0xFF6C63FF); // Purple - Main brand color
  static const Color primaryLight = Color(0xFF8B84FF);
  static const Color primaryDark = Color(0xFF5850E6);
  
  // Secondary Colors
  static const Color secondary = Color(0xFFFF6B9D); // Pink accent
  static const Color secondaryLight = Color(0xFFFF8FB5);
  static const Color secondaryDark = Color(0xFFE64F85);
  
  // Background Colors
  static const Color background = Color(0xFFF8F9FA); // Light gray background
  static const Color backgroundDark = Color(0xFFEEEFF1);
  
  // Surface Colors (Cards, Containers)
  static const Color surface = Color(0xFFFFFFFF); // White
  static const Color card = Color(0xFFFFFFFF);
  
  // Text Colors
  static const Color textPrimary = Color(0xFF2D3748); // Dark gray
  static const Color textSecondary = Color(0xFF718096); // Medium gray
  static const Color textMuted = Color(0xFF9AA0B2); // Light gray
  static const Color textWhite = Color(0xFFFFFFFF);
  
  // Status Colors
  static const Color success = Color(0xFF48BB78); // Green - completed tasks
  static const Color warning = Color(0xFFFF9800); // Orange - pending
  static const Color error = Color(0xFFF56565); // Red - urgent/overdue
  static const Color info = Color(0xFF4299E1); // Blue - information
  
  // Priority Colors
  static const Color priorityLow = Color(0xFF48BB78); // Green
  static const Color priorityMedium = Color(0xFFFF9800); // Orange
  static const Color priorityHigh = Color(0xFFFF5722); // Deep Orange
  static const Color priorityUrgent = Color(0xFFF44336); // Red
  
  // Category Colors (for different task categories)
  static const Color categoryWork = Color(0xFF6C63FF); // Purple
  static const Color categoryPersonal = Color(0xFFFF6B9D); // Pink
  static const Color categoryShopping = Color(0xFF48BB78); // Green
  static const Color categoryHealth = Color(0xFFFF9800); // Orange
  static const Color categoryFinance = Color(0xFF4299E1); // Blue
  static const Color categoryEducation = Color(0xFF9C27B0); // Deep Purple
  
  // Border Colors
  static const Color border = Color(0xFFE2E8F0);
  static const Color borderLight = Color(0xFFF0F4F8);
  static const Color borderDark = Color(0xFFCBD5E0);
  
  // Shadow Colors (for elevation effects)
  static const Color shadowLight = Color(0x0D000000); // 5% black
  static const Color shadowMedium = Color(0x1A000000); // 10% black
  static const Color shadowDark = Color(0x33000000); // 20% black
  
  // Overlay Colors
  static const Color overlay = Color(0x80000000); // 50% black
  static const Color overlayLight = Color(0x40000000); // 25% black
  
  // Gradient Colors
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF6C63FF), Color(0xFF8B84FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient secondaryGradient = LinearGradient(
    colors: [Color(0xFFFF6B9D), Color(0xFFFF8FB5)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  // Additional utility colors
  static const Color divider = Color(0xFFE2E8F0);
  static const Color disabled = Color(0xFFCBD5E0);
  static const Color disabledText = Color(0xFFA0AEC0);
}