import 'package:flutter/material.dart';
import '../themes/colors.dart';
import '../widgets/task_card.dart';
import '../models/sample_data.dart';

class TasksView extends StatelessWidget {
  const TasksView({super.key});

  @override
  Widget build(BuildContext context) {
    // Using actual Task models from sample_data
    final tasks = SampleData.getPendingTasks();
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Tasks'),
        backgroundColor: AppColors.primary,
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () {
              // Could add filter functionality
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Task summary
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                '${tasks.length} tasks pending',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 8),
            // Task list
            Expanded(
              child: ListView.separated(
                itemBuilder: (context, index) {
                  final task = tasks[index];
                  return TaskCard(
                    task: task, // Pass entire task object
                    onTap: () {
                      Navigator.pushNamed(
                        context,
                        '/task-details',
                        arguments: task, // Pass task object as argument
                      );
                    },
                  );
                },
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemCount: tasks.length,
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.primary,
        onPressed: () {
          Navigator.pushNamed(context, '/add-task');
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}