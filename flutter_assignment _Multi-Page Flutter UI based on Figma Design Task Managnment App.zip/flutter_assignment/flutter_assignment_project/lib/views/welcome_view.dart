import 'package:flutter/material.dart';
import '../themes/colors.dart';
import '../themes/app_theme.dart';
import '../widgets/custom_button.dart';

class WelcomeView extends StatelessWidget {
  const WelcomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              
              // Welcome Illustration
              Container(
                width: double.infinity,
                height: 300,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(AppTheme.radiusXl),
                ),
                child: Image.asset(
                  'assets/images/welcome_illustration.png',
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) {
                    // Fallback if image not found
                    return Container(
                      decoration: BoxDecoration(
                        color: AppColors.primary.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(AppTheme.radiusXl),
                      ),
                      child: Icon(
                        Icons.task_alt,
                        size: 120,
                        color: AppColors.primary,
                      ),
                    );
                  },
                ),
              ),
              
              const SizedBox(height: 40),
              
              // App Title
              Text(
                'Task Management',
                style: TextStyle(
                  fontSize: AppTheme.font3Xl,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
                textAlign: TextAlign.center,
              ),
              
              const SizedBox(height: 12),
              
              // Subtitle
              Text(
                'Organize your tasks and boost\nyour productivity',
                style: TextStyle(
                  fontSize: AppTheme.fontLg,
                  color: AppColors.textSecondary,
                  height: 1.5,
                ),
                textAlign: TextAlign.center,
              ),
              
              const Spacer(),
              
              // Get Started Button
              CustomButton(
                label: "Let's Start",
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/home');
                },
              ),
              
              const SizedBox(height: 16),
              
              // Already have account (optional)
              TextButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/home');
                },
                child: Text(
                  'Skip for now',
                  style: TextStyle(
                    color: AppColors.textMuted,
                    fontSize: AppTheme.fontMd,
                  ),
                ),
              ),
              
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}