import '../models/task_model.dart';

class SampleData {
  static final List<Task> tasks = [
    Task(
      id: '1',
      title: 'Design Landing Page',
      description: 'Create wireframes and mockups for the new product landing page. Focus on user experience and conversion optimization.',
      dueDate: DateTime.now().add(const Duration(days: 2)),
      priority: TaskPriority.high,
      category: 'Work',
      tags: ['design', 'ui/ux'],
    ),
    Task(
      id: '2',
      title: 'Flutter UI Implementation',
      description: 'Implement the task management app UI based on Figma prototype. Match colors, fonts, and spacing exactly.',
      dueDate: DateTime.now().add(const Duration(days: 5)),
      priority: TaskPriority.urgent,
      category: 'Work',
      tags: ['development', 'flutter'],
    ),
    Task(
      id: '3',
      title: 'Write Documentation',
      description: 'Update API documentation for the new endpoints. Include request/response examples and error codes.',
      dueDate: DateTime.now().add(const Duration(days: 3)),
      priority: TaskPriority.medium,
      category: 'Work',
      tags: ['documentation'],
    ),
    Task(
      id: '4',
      title: 'Team Meeting',
      description: 'Weekly standup meeting to discuss project progress and blockers.',
      dueDate: DateTime.now().add(const Duration(days: 1)),
      priority: TaskPriority.high,
      category: 'Work',
      tags: ['meeting'],
      isCompleted: true,
    ),
    Task(
      id: '5',
      title: 'Grocery Shopping',
      description: 'Buy groceries for the week: milk, eggs, bread, vegetables, and fruits.',
      dueDate: DateTime.now(),
      priority: TaskPriority.medium,
      category: 'Personal',
      tags: ['shopping', 'errands'],
    ),
    Task(
      id: '6',
      title: 'Gym Workout',
      description: 'Evening workout session: cardio 30 min, weights 45 min, stretching 15 min.',
      dueDate: DateTime.now(),
      priority: TaskPriority.low,
      category: 'Health',
      tags: ['fitness', 'health'],
    ),
    Task(
      id: '7',
      title: 'Read Book Chapter',
      description: 'Complete chapter 5 of "Clean Code" by Robert Martin.',
      dueDate: DateTime.now().add(const Duration(days: 1)),
      priority: TaskPriority.low,
      category: 'Personal',
      tags: ['reading', 'learning'],
    ),
    Task(
      id: '8',
      title: 'Code Review',
      description: 'Review pull requests from team members. Check for code quality, bugs, and best practices.',
      dueDate: DateTime.now().add(const Duration(hours: 6)),
      priority: TaskPriority.urgent,
      category: 'Work',
      tags: ['development', 'review'],
    ),
  ];

  // Get tasks by category
  static List<Task> getTasksByCategory(String category) {
    return tasks.where((task) => task.category == category).toList();
  }

  // Get tasks by priority
  static List<Task> getTasksByPriority(TaskPriority priority) {
    return tasks.where((task) => task.priority == priority).toList();
  }

  // Get completed tasks
  static List<Task> getCompletedTasks() {
    return tasks.where((task) => task.isCompleted).toList();
  }

  // Get pending tasks
  static List<Task> getPendingTasks() {
    return tasks.where((task) => !task.isCompleted).toList();
  }

  // Get tasks due today
  static List<Task> getTasksDueToday() {
    final now = DateTime.now();
    return tasks.where((task) {
      return task.dueDate.year == now.year &&
          task.dueDate.month == now.month &&
          task.dueDate.day == now.day;
    }).toList();
  }

  // Get overdue tasks
  static List<Task> getOverdueTasks() {
    final now = DateTime.now();
    return tasks.where((task) {
      return !task.isCompleted && task.dueDate.isBefore(now);
    }).toList();
  }
}