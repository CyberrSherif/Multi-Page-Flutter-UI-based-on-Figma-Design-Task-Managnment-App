import 'package:flutter/material.dart';

class TaskCategory {
  final String id;
  final String name;
  final IconData icon;
  final Color color;
  final int taskCount;

  TaskCategory({
    required this.id,
    required this.name,
    required this.icon,
    required this.color,
    this.taskCount = 0,
  });

  TaskCategory copyWith({
    String? id,
    String? name,
    IconData? icon,
    Color? color,
    int? taskCount,
  }) {
    return TaskCategory(
      id: id ?? this.id,
      name: name ?? this.name,
      icon: icon ?? this.icon,
      color: color ?? this.color,
      taskCount: taskCount ?? this.taskCount,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'iconCodePoint': icon.codePoint,
      'colorValue': color.value,
      'taskCount': taskCount,
    };
  }

  factory TaskCategory.fromJson(Map<String, dynamic> json) {
    return TaskCategory(
      id: json['id'],
      name: json['name'],
      icon: IconData(json['iconCodePoint'], fontFamily: 'MaterialIcons'),
      color: Color(json['colorValue']),
      taskCount: json['taskCount'] ?? 0,
    );
  }
}

// Sample categories - customize based on Figma design
class DefaultCategories {
  static final List<TaskCategory> all = [
    TaskCategory(
      id: '1',
      name: 'Work',
      icon: Icons.work_outline,
      color: const Color(0xFF6C63FF),
      taskCount: 6,
    ),
    TaskCategory(
      id: '2',
      name: 'Personal',
      icon: Icons.person_outline,
      color: const Color(0xFFFF6584),
      taskCount: 3,
    ),
    TaskCategory(
      id: '3',
      name: 'Shopping',
      icon: Icons.shopping_bag_outlined,
      color: const Color(0xFF4CAF50),
      taskCount: 4,
    ),
    TaskCategory(
      id: '4',
      name: 'Health',
      icon: Icons.favorite_outline,
      color: const Color(0xFFFF9800),
      taskCount: 2,
    ),
  ];
}